//
//  TableViewController.h
//  ToolBox
//
//  Created by Willson Ayotte (NEW) on 5/8/13.
//  Copyright (c) 2013 Willson Ayotte (NEW). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewController : UITableViewCell
{
    
}
@property (nonatomic, strong)IBOutlet UILabel *toolName;
@property (nonatomic, strong)IBOutlet UILabel *kindLabel;
@end