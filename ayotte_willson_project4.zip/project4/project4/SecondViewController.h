//
//  SecondViewController.h
//  project4
//
//  Created by Willson Ayotte (NEW) on 5/28/13.
//  Copyright (c) 2013 Willson Ayotte (NEW). All rights reserved.
//

// pulling in the first View
#import <UIKit/UIKit.h>
#import "FirstViewController.h"


@interface SecondViewController : UIViewController
{
    IBOutlet UITextView *myTextView;
}


@end
